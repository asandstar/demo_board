#ifndef _SYS_H
#define _SYS_H

#include "gd32f4xx.h"
#include "systick.h"

/*
LED1 PE3
LED2 PD7
LED3 PG3
LED4 PA5
*/

#define BIT_ADDR(byte_offset,bit_number)  (volatile unsigned long*)(0x42000000 +(byte_offset*32)+(bit_number*4))
	
#define GPIOE_OCTL_OFFSET ((GPIOE+0x14)-0x40000000)
#define GPIOD_OCTL_OFFSET ((GPIOD+0x14)-0x40000000)
#define GPIOG_OCTL_OFFSET ((GPIOG+0x14)-0x40000000)
#define GPIOA_OCTL_OFFSET ((GPIOA+0x14)-0x40000000)

#define PDout1(n) *(BIT_ADDR(GPIOE_OCTL_OFFSET,n))
#define PDout2(n) *(BIT_ADDR(GPIOD_OCTL_OFFSET,n))
#define PDout3(n) *(BIT_ADDR(GPIOG_OCTL_OFFSET,n))
#define PDout4(n) *(BIT_ADDR(GPIOA_OCTL_OFFSET,n))


#endif
